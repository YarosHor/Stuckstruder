# Pruebas varias

## Pupurri de *código fuente* para aplicaciones *Spring Boot*

1. POM
1. aplication.properties
1. th:replace -> fragment
1.  @GetMapping

